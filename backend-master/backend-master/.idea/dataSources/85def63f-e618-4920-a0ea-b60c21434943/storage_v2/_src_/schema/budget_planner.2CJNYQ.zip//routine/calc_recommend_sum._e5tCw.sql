create procedure calc_recommend_sum(OUT recommend_sum double)
  BEGIN
	DECLARE sum1 INT;
	DECLARE sum2 INT;
	SET sum1  = (
		SELECT id_budget, SUM(id_budget*spending)  
		FROM Budget
		GROUP BY id_budget);
    SET sum2  = (
		SELECT id_budget, SUM(id_budget)  
		FROM Budget
		GROUP BY id_budget);
		SET recommend_sum = sum1/sum2;   
END;

