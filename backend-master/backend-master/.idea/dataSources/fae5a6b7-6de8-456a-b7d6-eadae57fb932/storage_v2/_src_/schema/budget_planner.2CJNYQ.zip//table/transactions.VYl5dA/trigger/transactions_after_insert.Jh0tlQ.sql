create trigger transactions_AFTER_INSERT
  after INSERT
  on transactions
  for each row
  BEGIN
UPDATE Budget 
SET Budget.spending = NEW.cost + Budget.spending
WHERE Budget.id_category = NEW.id_category AND MONTH(NEW.date) = MONTH(Budget.date);
END;

